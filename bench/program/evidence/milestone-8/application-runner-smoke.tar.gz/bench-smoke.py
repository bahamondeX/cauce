from contextlib import ExitStack
import subprocess
from pathlib import Path
import sys
import time

ROOT = Path.cwd()
OUT = ROOT / 'work/milestone-8'
reference = ROOT / 'work/milestone-7/nginx-1.30.8/objs/nginx'
php = 'php@sha256:d39ec536545f1f698dc971cd2a0a77424867a27a992dd43b8e82d5cf112b02cb'
fixture = ROOT / 'tests/application/main.php'
for proto in ('fastcgi','uwsgi','scgi'):
    with ExitStack() as cleanup:
        if proto == 'fastcgi':
            port = 9000
            cmd = ['-v', f'{fixture}:/fixture/main.php:ro', php]
        else:
            port = 9000
            cmd = ['cauce-m8-wsgi', 'uwsgi', '--plugin', 'python3',
                   '--scgi-socket' if proto == 'scgi' else '--socket', f'0.0.0.0:{port}',
                   '--wsgi-file', '/fixture/wsgi_fixture.py', '--callable', 'application',
                   '--die-on-term', '--master', '--processes', '1']
        cid = subprocess.check_output(['docker', 'run', '-d', '--rm', '--pull=never',
                                      '-p', f'127.0.0.1::{port}', *cmd], text=True).strip()
        cleanup.callback(subprocess.run, ['docker', 'stop', '-t', '1', cid], check=True, stdout=subprocess.DEVNULL)
        listen = subprocess.check_output(['docker', 'port', cid, str(port)], text=True).strip().rsplit(':', 1)[1]
        image = subprocess.check_output(['docker', 'inspect', '--format={{.Image}}', cid], text=True).strip()
        time.sleep(1)
        for engine, binary in [('cauce', ROOT / 'target/debug/cauce'), ('nginx', reference)]:
            case = OUT / f'benchmark-smoke-{proto}-{engine}'
            cmd = [sys.executable, str(ROOT / 'bench/program/network-benchmark.py'), proto, engine, str(case),
                   '--proxy', str(binary), '--origin-identity', image, '--origin-port', listen,
                   '--rate', '8', '--seconds', '1', '--warmup', '1', '--inflight', '4',
                   '--request-size', '131072', '--size', '131072', '--timeout', '3']
            if proto == 'fastcgi':
                cmd.append('--fastcgi-keepalive')
            subprocess.run(cmd, check=True)
