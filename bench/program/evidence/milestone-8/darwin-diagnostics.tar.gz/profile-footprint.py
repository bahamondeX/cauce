"""Capture one-worker HTTP/1.1 memory snapshots for the three Darwin builds."""
import argparse
from http.client import HTTPConnection
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / "bench/program"))
from telemetry import LAB, available_port, http, process, process_stats, proxy_config, until

out = Path(sys.argv[1])
out.mkdir()
backend, stats = available_port(), available_port()
env = {**os.environ, "PORT": str(backend), "BENCH_STATS_PORT": str(stats),
       "BENCH_BIND": "127.0.0.1", "TLS": "0"}
process_env = {**os.environ, "TOKIO_WORKER_THREADS": "1", "CAUCE_POOL_STRATEGY": "compact",
               "CAUCE_TRANSPORT_DIAGNOSTICS": "0"}
def sample(proxy, folder, phase):
    (folder / f"{phase}-rss.json").write_text(json.dumps(process_stats(proxy.pid), indent=2) + "\n")
    for command, name in [(["vmmap", "-summary"], "vmmap"), (["heap", "-s", "-q"], "heap")]:
        with (folder / f"{phase}.{name}").open("w") as f:
            subprocess.run([*command, str(proxy.pid)], stdout=f, stderr=subprocess.STDOUT,
                           text=True, timeout=15)
        target = folder / f"{phase}.{name}"
        target.write_text(target.read_text().replace(str(ROOT), "<workspace>"))

with process(["node", str(LAB / "backend/server.mjs")], out / "backend.log", env) as server:
    until(server, lambda: http(stats, "/stats"), 5)
    for pair in sys.argv[2:]:
        label, path = pair.split("=", 1)
        folder = out / label
        folder.mkdir()
        port, admin = available_port(), available_port()
        config = folder / "cauce.toml"
        cfg = proxy_config(argparse.Namespace(protocol="http1", routes=1), port, admin,
                           backend, folder / "access.jsonl", False)
        config.write_text(cfg)
        with process([str(Path(path).resolve()), str(config)], folder / "proxy.log", process_env) as proxy:
            until(proxy, lambda: http(admin, "/ready"), 5)
            sample(proxy, folder, "idle")
            conn = HTTPConnection("127.0.0.1", port, timeout=3)
            for _ in range(200):
                conn.request("GET", "/echo")
                resp = conn.getresponse()
                assert resp.status == 200 and resp.read() == b"x" * 1024
            conn.close()
            sample(proxy, folder, "loaded")
