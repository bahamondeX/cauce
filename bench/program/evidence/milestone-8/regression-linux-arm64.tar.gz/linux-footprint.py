"""Capture local VM RSS, PSS and private pages for unchanged HTTP-only settings."""
from contextlib import ExitStack
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
import time
import tomllib

root=Path.cwd()
start = tomllib.loads((root/'examples/stream.toml').read_text().split('[[stream.upstreams]]',1)[0])
start.update(listen='0.0.0.0:8080', routes=[{'id':'snapshot','host':'fixture.test','path_prefix':'/',
             'content':{'type':'direct','status':200,'body':'x'*1024}}])
results = {}
def docker(*args):
    return subprocess.check_output(['docker',*args],text=True).strip()
with TemporaryDirectory(dir=root/'work/milestone-8') as temp:
    config = Path(temp)/'profile.yaml'
    config.write_text(json.dumps(dict(version=1,proxy=start)))
    config.chmod(0o644)
    for image in ('cauce:milestone7-arm64','cauce:milestone8-arm64'):
        with ExitStack() as resources:
            cid=docker('run','-d','--rm','--pull=never','-e','TOKIO_WORKER_THREADS=1',
                       '-v',f'{config}:/snapshot.yaml:ro',image,'/snapshot.yaml')
            resources.callback(docker,'stop','-t','1',cid)
            deadline=time.monotonic()+15
            while '"event":"started"' not in subprocess.run(['docker','logs',cid],
                    capture_output=True,text=True,check=True).stderr:
                if time.monotonic() > deadline:
                    raise RuntimeError('gateway did not start')
                time.sleep(.1)
            def sample():
                keys={'Rss','Pss','Shared_Clean','Private_Dirty','Private_Clean'}
                return {key:int(value.split()[0]) for row in docker('exec',cid,'cat','/proc/1/smaps_rollup').splitlines()
                        for key, _, value in [row.partition(':')] if key in keys}
            idle=sample()
            docker('run','--rm','--pull=never', '--network', f'container:{cid}', 'cauce-m8-wsgi','python','-c',
                   "from http.client import HTTPConnection\n"
                   "conn=HTTPConnection('127.0.0.1',8080,timeout=5)\n"
                   "for _ in range(200):\n"
                   "    conn.request('GET','/',headers={'Host':'fixture.test'})\n"
                   "    r=conn.getresponse()\n"
                   "    assert r.status==200 and r.read()==b'x'*1024\n"
                   "conn.close()")
            results[image]={'idle_kib':idle,'loaded_kib':sample(),
                            'binary_sha256':docker('exec',cid,'sha256sum','/usr/local/bin/cauce').split()[0]}
print(json.dumps(results,indent=2))
