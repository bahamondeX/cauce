# Resultados locales

Mediana entre repeticiones. CPU 100% = un núcleo; RSS suma procesos del proxy.
RSS puede contar páginas compartidas varias veces; memoria cgroup cuenta el contenedor e incluye caché.
CPU usa timestamps del Engine alrededor de carga + drenaje, con margen de polling; intervalos por corrida en el CSV.
Throughput = respuestas útiles / tiempo total incluido drenaje. Latencia desde llegada programada, solo éxito.

| Escenario | Logs | Proxy | r/s ofrecidos | r/s útiles | p50 ms | p95 ms | p99 ms | CPU % | RSS máx. observado MiB | Cgroup máx. observado MiB | HTTP errores | Otros errores/drops |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| normal | off | candidate | 250 | 250.00 | 1.61 | 2.66 | 13.19 | 4.05 | 6.00 | 2.53 | 0 | 0 |
| normal | off | cauce | 250 | 250.00 | 1.56 | 2.59 | 9.56 | 4.13 | 5.88 | 2.55 | 0 | 0 |
| normal | off | nginx | 250 | 250.00 | 1.47 | 2.52 | 15.18 | 3.50 | 9.03 | 3.03 | 0 | 0 |
| normal | on | candidate | 250 | 250.00 | 1.57 | 2.58 | 11.26 | 4.81 | 8.12 | 6.55 | 0 | 0 |
| normal | on | cauce | 250 | 250.00 | 1.58 | 2.61 | 13.44 | 4.94 | 7.88 | 6.51 | 0 | 0 |
| normal | on | nginx | 250 | 250.00 | 1.09 | 1.85 | 14.31 | 3.74 | 9.94 | 3.78 | 0 | 0 |

Los rangos mínimo/máximo por repetición están en `comparison.json`; todas las corridas en `comparison.csv`.
Las corridas con jitter p99 del generador >10 ms se marcan como `generator_comparison_limited`; sus latencias incluyen esa interferencia y no permiten atribuir el retraso exclusivamente al proxy.
También se conserva throughput completado dentro de la ventana ofrecida (`offer_window_goodput_rps`) y éxitos totales / duración ofrecida (`successes_per_offer_duration`, incluye éxitos del drenaje).
Los errores HTTP se contabilizan por separado; los 503 de saturación no se consideran respuestas útiles.
