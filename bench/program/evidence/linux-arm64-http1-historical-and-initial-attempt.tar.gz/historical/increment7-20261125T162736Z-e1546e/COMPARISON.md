# Resultados locales

Mediana entre repeticiones. CPU 100% = un núcleo; RSS suma procesos del proxy.
RSS puede contar páginas compartidas varias veces; memoria cgroup cuenta el contenedor e incluye caché.
CPU usa timestamps del Engine alrededor de carga + drenaje, con margen de polling; intervalos por corrida en el CSV.
Throughput = respuestas útiles / tiempo total incluido drenaje. Latencia desde llegada programada, solo éxito.

| Escenario | Logs | Proxy | r/s ofrecidos | r/s útiles | p50 ms | p95 ms | p99 ms | CPU % | RSS máx. observado MiB | Cgroup máx. observado MiB | HTTP errores | Otros errores/drops |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| normal | off | cauce | 500.0 | 499.93 | 1.56 | 2.90 | 4.61 | 7.50 | 5.75 | 2.53 | 0 | 0 |
| normal | off | nginx | 500.0 | 499.95 | 1.59 | 2.91 | 5.27 | 6.02 | 12.31 | 3.40 | 0 | 0 |
| normal | on | cauce | 500.0 | 499.94 | 1.59 | 2.86 | 4.45 | 8.69 | 7.62 | 8.09 | 0 | 0 |
| normal | on | nginx | 500.0 | 499.94 | 1.60 | 2.81 | 4.79 | 6.80 | 13.31 | 4.68 | 0 | 0 |

Los rangos mínimo/máximo por repetición están en `comparison.json`; todas las corridas en `comparison.csv`.
Las corridas con jitter p99 del generador >50 ms se marcan como `generator_comparison_limited`; sus latencias incluyen esa interferencia y no permiten atribuir el retraso exclusivamente al proxy.
También se conserva throughput completado dentro de la ventana ofrecida (`offer_window_goodput_rps`) y éxitos totales / duración ofrecida (`successes_per_offer_duration`, incluye éxitos del drenaje).
Los errores HTTP se contabilizan por separado; los 503 de saturación no se consideran respuestas útiles.
