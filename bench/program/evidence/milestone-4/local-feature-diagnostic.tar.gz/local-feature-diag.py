import argparse
import json
import os
from pathlib import Path
import random
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("lab", type=Path)
parser.add_argument("stage_bin", type=Path)
args = parser.parse_args()
lab = args.lab.resolve()
stage = args.stage_bin.resolve()
runner = lab / "integration/bench/program/capacity-workload.py"
out = lab / "local-feature-diagnostic"
out.mkdir()
roles = {"proxy": [0], "backend": [1], "generator": [2], "sampler": [3]}
cases = {
    "baseline-off": ("cauce-168ed82", []),
    "milestone4-off": ("cauce-d20c509", []),
    "milestone4-regex": ("cauce-d20c509", ["--route-match", "regex"]),
    "milestone4-headers": ("cauce-d20c509", ["--header-policy"]),
}
plan = {"architecture": "Colima AArch64", "roles": roles, "rate": 500, "seconds": 2, "warmup_seconds": 1,
        "seed": 87340, "blocks": 3, "purpose": "local diagnostic. Record gates without release performance claims."}
(out/"plan.json").write_text(json.dumps(plan, indent=2)+"\n")
rng = random.Random(plan["seed"])
rows = []
for block in range(1, plan["blocks"] + 1):
    order = list(cases)
    rng.shuffle(order)
    for name in order:
        binary, flags = cases[name]
        run = out / f"{block}-{name}"
        command = [sys.executable, str(runner), str(lab/"linux-arm64"/binary), str(stage/"cauce-load"), str(run),
                   "--protocol", "http1", "--workers", "1", "--proxy-cpus", "0", "--backend-cpu", "1",
                   "--client-cpu", "2", "--sampler-cpu", "3", "--p99-ms", "20", "--p999-ms", "100",
                   "--rates", str(plan["rate"]), "--seconds", str(plan["seconds"]),
                   "--warmup", str(plan["warmup_seconds"]), "--confirm-seconds", "60", "--matched", *flags]
        env = os.environ | {"PATH":str(stage) + ":" + os.environ["PATH"]}
        with (out/f"{block}-{name}.log").open("w") as stream:
            rc = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, env=env, check=False).returncode
        row = dict(block=block, order=order, name=name, exit_code=rc)
        if (run/"matched.json").is_file():
            matched = json.loads((run/"matched.json").read_text())
            row["qualified"] = matched["qualified"]
            target = matched["target"]
            for key in ("rate", "outcomes", "offered", "goodput_per_s", "cpu_us_per_success",
                        "scheduled_latency_ns", "warmup_outcomes", "invalid_reasons"):
                row[key] = target.get(key)
            if target.get("process"):
                row["rss_peak_bytes"] = target["process"]["rss_peak_sampled_bytes"]
                row["pss_end_bytes"] = target["process"]["after"]["pss_bytes"]
        rows.append(row)
        print(json.dumps(row),flush=True)
(out/"summary.json").write_text(json.dumps(rows,indent=2)+"\n")
