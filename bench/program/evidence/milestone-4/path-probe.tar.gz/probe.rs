use std::{alloc::{GlobalAlloc, Layout, System}, hint::black_box, sync::atomic::{AtomicUsize, Ordering::Relaxed}, time::Instant};
struct Count;
static ALLOCS: AtomicUsize = AtomicUsize::new(0);
#[global_allocator]
static ALLOCATOR: Count = Count;
unsafe impl GlobalAlloc for Count {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        ALLOCS.fetch_add(1, Relaxed);
        unsafe { System.alloc(layout) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
}
#[inline(never)]
fn before(path: &str) -> bool {
    // Routing rejects ambiguous encodings rather than guessing backend normalization.
    if path.contains(['\\', '#']) || path.contains("//") {
        return false;
    }
    let lower = path.to_ascii_lowercase();
    if ["%2f", "%5c", "%2e", "%25", "%00", "%0a", "%0d"]
        .iter()
        .any(|s| lower.contains(s))
    {
        return false;
    }
    !path
        .split('/')
        .any(|segment| segment == "." || segment == "..")
}

#[inline(never)]
fn after(path: &str) -> bool {
    // Routing rejects ambiguous encodings rather than guessing backend normalization.
    if path.contains(['\\', '#']) || path.contains("//") {
        return false;
    }
    if path.split('%').skip(1).any(|encoded| {
        let Some([high, low]) = encoded.as_bytes().get(..2) else {
            return false;
        };
        matches!(
            (*high, low.to_ascii_lowercase()),
            (b'2', b'f' | b'e' | b'5') | (b'5', b'c') | (b'0', b'0' | b'a' | b'd')
        )
    }) {
        return false;
    }
    !path
        .split('/')
        .any(|segment| segment == "." || segment == "..")
}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let count = 262144;
    for (shape, samples) in [
        ("common", ["/echo", "/api/v1/items/abc123", "/read/a.html"]),
        ("encoded", ["/api/one%20two", "/api/%2Fbad", "/a/caf%C3%A9"]),
    ] {
        for f in [before as fn(&str) -> bool, after] {
            for i in 0..32768 {
                black_box(f(black_box(samples[i % samples.len()])));
            }
        }
        for (name, f) in match args[1].as_str() {
            "ab" => [("before", before as fn(&str)->bool), ("after", after as fn(&str)->bool)],
            _ => [("after", after as fn(&str)->bool), ("before", before as fn(&str)->bool)],
        } {
            let initial = ALLOCS.load(Relaxed);
            let now = Instant::now();
            for i in 0..count {
                black_box(f(black_box(samples[i % samples.len()])));
            }
            let elapsed = now.elapsed().as_nanos();
            let allocations = ALLOCS.load(Relaxed) - initial;
            println!("{shape},{name},{count},{elapsed},{allocations}");
        }
    }
}
