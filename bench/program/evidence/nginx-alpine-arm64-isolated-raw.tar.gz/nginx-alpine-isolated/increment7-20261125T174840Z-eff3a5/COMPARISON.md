# Resultados locales

Mediana entre repeticiones. CPU 100% = un núcleo; RSS suma procesos del proxy.
RSS puede contar páginas compartidas varias veces; memoria cgroup cuenta el contenedor e incluye caché.
CPU usa timestamps del Engine alrededor de carga + drenaje, con margen de polling; intervalos por corrida en el CSV.
Throughput = respuestas útiles / tiempo total incluido drenaje. Latencia desde llegada programada, solo éxito.

| Escenario | Logs | Proxy | r/s ofrecidos | r/s útiles | p50 ms | p95 ms | p99 ms | CPU % | RSS máx. observado MiB | Cgroup máx. observado MiB | HTTP errores | Otros errores/drops |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| normal | off | cauce | 250.0 | 249.95 | 2.05 | 3.30 | 5.81 | 4.70 | 5.88 | 2.62 | 0 | 0 |
| normal | off | nginx | 250.0 | 249.97 | 1.73 | 3.44 | 11.72 | 3.74 | 8.94 | 3.04 | 0 | 0 |
| normal | on | cauce | 250.0 | 249.96 | 2.11 | 3.66 | 5.68 | 5.65 | 7.88 | 6.28 | 0 | 0 |
| normal | on | nginx | 250.0 | 249.97 | 1.89 | 3.03 | 4.09 | 4.84 | 9.82 | 3.73 | 0 | 0 |

Los rangos mínimo/máximo por repetición están en `comparison.json`; todas las corridas en `comparison.csv`.
Las corridas con jitter p99 del generador >50 ms se marcan como `generator_comparison_limited`; sus latencias incluyen esa interferencia y no permiten atribuir el retraso exclusivamente al proxy.
También se conserva throughput completado dentro de la ventana ofrecida (`offer_window_goodput_rps`) y éxitos totales / duración ofrecida (`successes_per_offer_duration`, incluye éxitos del drenaje).
Los errores HTTP se contabilizan por separado; los 503 de saturación no se consideran respuestas útiles.
