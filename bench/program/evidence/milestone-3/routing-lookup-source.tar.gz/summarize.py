from pathlib import Path
import json, random, statistics, subprocess

root = Path(__file__).resolve().parent
rng = random.Random(29080)
def calc(label, workload, count):
    return float(subprocess.check_output([root / label / "probe", workload, str(count)], text=True))
def compare(count):
    raw = []
    for _ in range(7):
        order = ["baseline", "candidate"]
        rng.shuffle(order)
        raw.append({label: calc(label, "disabled", count) for label in order})
    d = [x["candidate"] - x["baseline"] for x in raw]
    boot = sorted(statistics.median(rng.choices(d,k=7)) for _ in range(10000))
    return {"disabled_raw_ns_per_lookup":raw,"paired_delta_ci95":[boot[250],boot[9749]],
            "delta_median":statistics.median(d),
            "enabled_raw_ns_per_lookup":{
                mode:[calc("candidate",mode,count) for _ in range(7)]
                for mode in ("wildcard","exact-path")}}
print(json.dumps({str(count):compare(count) for count in (1,1024)},indent=2))
