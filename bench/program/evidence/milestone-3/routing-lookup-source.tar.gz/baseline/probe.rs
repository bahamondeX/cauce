#![allow(dead_code)]
mod config {
    #[derive(Clone, Copy)]
    pub enum PathMatch { Prefix, Exact }
    pub struct Route {
        pub id: String,
        pub host: String,
        pub path_prefix: String,
        #[cfg(candidate)]
        pub path_match: PathMatch,
        pub balance: u8,
        pub upstreams: Vec<String>,
    }
}
mod routing;
use config::{PathMatch, Route};
use std::{hint::black_box, time::Instant};

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let mode = &args[1];
    let count: usize = args[2].parse().unwrap();
    let routes: Vec<_> = (0..count).map(|index| Route {
        id: format!("r{index}"),
        host: if mode == "wildcard" { format!("*.host{index}.test") } else { format!("host{index}.test") },
        path_prefix: format!("/paths/{index}"),
        #[cfg(candidate)]
        path_match: if mode == "exact-path" { PathMatch::Exact } else { PathMatch::Prefix },
        balance: 1,
        upstreams: vec![String::from("origin")],
    }).collect();
    let queries: Vec<_> = routes.iter().map(|r| {
        let host = r.host.replacen('*', "tenant", 1);
        let path = if mode == "exact-path" { r.path_prefix.clone() } else {
            format!("{}/items", r.path_prefix)
        };
        (host, path)
    }).collect();
    let compiled = routing::Routes::compile(&routes);
    let offers = 2_000_000;
    let measure = || {
        for i in 0..offers {
            let (host, path) = &queries[(i * 239) % count];
            let found = compiled.find(&routes, black_box(host), black_box(path));
            black_box(found.expect("expected route"));
        }
    };
    measure();
    let start = Instant::now();
    measure();
    println!("{}", start.elapsed().as_nanos() as f64 / offers as f64);
}
